# Client Samples

The following table shows the sample sub-directories and their contents.

Directory       | Description
----------------| -------------
common          | Samples common helper classes and abstractions; This package contains one sample 'connect_with_cert.py', to demonstrate how to connect with valid Cert Verification
appliances      | Samples for Appliance APIs
oauth           | Samples for oAuth APIs (IDP Federated vCenter Server)
compute_policy  | Samples for Compute Policy APIs
contentlibrary  | Samples for Content Library APIs
tagging         | Samples for Tagging APIs
vcenter         | Samples for managing vSphere infrastructure and virtual machines
sso             | Samples for Platform Service Controller(PSC), SSO and Lookup Service APIs
